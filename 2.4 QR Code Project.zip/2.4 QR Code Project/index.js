
//1. Use the inquirer npm package to get user input.
import inquirer from "inquirer";
import qr from 'qr-image';
import fs from "fs";
//var qr = require('qr-image');

inquirer
  .prompt([{
    message: "Type in your URL: ",
    name: "URL"
  }
    /* Pass your questions in here */
  ])
  .then((answers) => {
    const url = answers.URL; // storing the user input
    var qr_svg = qr.image(url); // creating the qr-code using the url provided
    qr_svg.pipe(fs.createWriteStream('qr_img.png'));

    // Store the url in the text file
    fs.writeFile('URL.txt', url, (err) => {
        if (err) throw err;
        console.log('The file has been saved!');
      }); 



    // Use user feedback for... whatever!!
  })
  .catch((error) => {
    if (error.isTtyError) {
      // Prompt couldn't be rendered in the current environment
    } else {
      // Something else went wrong
    }
  });





